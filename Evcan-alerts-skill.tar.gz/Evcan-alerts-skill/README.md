# <img src="https://raw.githack.com/FortAwesome/Font-Awesome/master/svgs/solid/robot.svg" card_color="#40DBB0" width="50" height="50" style="vertical-align:bottom"/> Noaa Alerts
Checks the noaa's national weather service for alerts in your reg

## About
This skill checks the national oceanic and atmospheric administration's (noaa) national weather service for active weather alerts in your region.
To get this skill working you must go to https://alerts.weather.gov/#us and find your region/zone ID. Enter that ID in the skills configuration at home.mycroft.ai

## Examples
* "Are there weather alerts"

## Credits
Dominik (@domcross)

## Category
**Daily**
Weather
Warning
Alert

## Tags
#Weather warning
#Noaa

